'use strict';

eventsApp.controller('SampleDirectiveController',
    function SampleDirectiveController($scope) {

    }
);